/// <reference path="../.astro/types.d.ts" />
